# Project K
A tiny interactive universe for Kelsey: intro signal, 3-question quiz, sealed letter, make-a-wish, ambient music.

Edit the `CFG` block at the top of `script.js` (questions, letter, names), commit, and the live site updates in about a minute.
Wishes are saved only in the visitor's own browser (localStorage). No backend, no paid APIs.

Deploy: GitHub repo -> Settings -> Pages -> Branch `main`, folder `/ (root)`.
